const express = require('express');
const crypto = require('crypto');

const app = express();
app.use(express.json());


let reclamacoes = [
  {
    id: crypto.randomUUID(),
    titulo: "NPCs atravessando o asfalto em Ocean Beach",
    descricao: "Durante a missão inicial, os NPCs atravessaram o chão e caíram no limbo.",
    categoria: "Bug Visual",
    autor: "TheLightLord",
    prioridade: "Alta",
    status: "Aberta",
    dataCriacao: new Date().toLocaleDateString("pt-BR")
  }
];


const validarCorpo = (body) => {
  const campos = ['titulo', 'descricao', 'categoria', 'autor', 'prioridade', 'status'];
  return campos.every(campo => body[campo] && body[campo].toString().trim() !== "");
};


app.get('/', (req, res) => {
  res.status(200).json({
    descricao: "API de Gerenciamento de Reclamações de Bugs",
    rotas: [
      { metodo: "GET", path: "/", descricao: "Documentação da API" },
      { metodo: "GET", path: "/reclamacoes", descricao: "Listar todas as reclamações" },
      { metodo: "GET", path: "/reclamacoes/:id", descricao: "Buscar reclamação por ID" },
      { 
        metodo: "POST", 
        path: "/reclamacoes", 
        descricao: "Criar nova reclamação",
        bodyEsperado: { titulo: "string", descricao: "string", categoria: "string", autor: "string", prioridade: "string", status: "string" }
      },
      { 
        metodo: "PUT", 
        path: "/reclamacoes/:id", 
        descricao: "Atualizar reclamação existente",
        bodyEsperado: { titulo: "string", descricao: "string", categoria: "string", autor: "string", prioridade: "string", status: "string" }
      },
      { metodo: "DELETE", path: "/reclamacoes/:id", descricao: "Remover reclamação por ID" }
    ]
  });
});


app.get('/reclamacoes', (req, res) => {
  res.status(200).json(reclamacoes);
});


app.get('/reclamacoes/:id', (req, res) => {
  const item = reclamacoes.find(r => r.id === req.params.id);
  if (!item) {
    return res.status(404).json({ mensagem: "Reclamação não encontrada." });
  }
  res.status(200).json(item);
});


app.post('/reclamacoes', (req, res) => {
  if (!validarCorpo(req.body)) {
    return res.status(400).json({ mensagem: "Todos os campos são obrigatórios e não podem estar vazios." });
  }

  const novaReclamacao = {
    id: crypto.randomUUID(),
    titulo: req.body.titulo.trim(),
    descricao: req.body.descricao.trim(),
    categoria: req.body.categoria.trim(),
    autor: req.body.autor.trim(),
    prioridade: req.body.prioridade.trim(),
    status: req.body.status.trim(),
    dataCriacao: new Date().toLocaleDateString("pt-BR")
  };

  reclamacoes.push(novaReclamacao);
  res.status(201).json({ mensagem: "Reclamação registrada com sucesso.", reclamacao: novaReclamacao });
});


app.put('/reclamacoes/:id', (req, res) => {
  if (!validarCorpo(req.body)) {
    return res.status(400).json({ mensagem: "Todos os campos são obrigatórios e não podem estar vazios." });
  }

  const reclamacao = reclamacoes.find(r => r.id === req.params.id);
  if (!reclamacao) {
    return res.status(404).json({ mensagem: "Reclamação não encontrada." });
  }

  Object.assign(reclamacao, {
    titulo: req.body.titulo.trim(),
    descricao: req.body.descricao.trim(),
    categoria: req.body.categoria.trim(),
    autor: req.body.autor.trim(),
    prioridade: req.body.prioridade.trim(),
    status: req.body.status.trim()
  });

  res.status(200).json({ mensagem: "Reclamação atualizada com sucesso.", reclamacao });
});


app.delete('/reclamacoes/:id', (req, res) => {
  const index = reclamacoes.findIndex(r => r.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ mensagem: "Reclamação não encontrada." });
  }

  reclamacoes.splice(index, 1);
  res.status(200).json({ mensagem: "Reclamação excluída com sucesso." });
});


app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});